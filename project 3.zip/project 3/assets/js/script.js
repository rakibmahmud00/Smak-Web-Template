new WOW().init();

jQuery(document).ready(function () {



    $(window).load(function () {
        setTimeout(function () {
            $('.preloader').fadeOut()
        }, 3000)
    })
    $('.count').counterUp({
        delay: 10,
        time: 1500
    });

    // $('#circle').circleProgress({
    //     value: 0.8,
    //     size: 100,
    //     fill: {
    //         gradient: ["#ffe600", "#ffe600"]
    //     },
    //     startAngle: 1.6,
    //     thickness: 5,
    //     animation: {
    //         duration: 2000,
    //         easing: "circleProgressEasing"
    //     },

    // });

    $("a[rel^='prettyPhoto']").prettyPhoto({
        show_title: true,
        nav: false,
    });

    $(".closer").click(function () {
        $('.our-awesome-image').hide(400);
    })

    var filter_container = ".portfolio-items";
    var mixer = mixitup(filter_container, {
        load: {
            filter: 'all'
        }
    });


    $('.mem1').click(function () {
        $('.mem-name').html("Robert");
        $('.mem-ab-text-area').fadeIn(300)
        $('.mem-fb').attr('href', 'https://www.facebook/profile.php/robert12.com');
        $('.mem-tw').attr('href', 'https://www.twitter/profile.php/robert12.com');
        $('.mem-ab').html('Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamussuscipit tortor egetfelis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla porttitor accumsan tincidunt. Cras ultricies ligula sed magna dictumporta. Curabitur non nulla sit amet nisl tempusconvallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.Mauris blandit aliquet elit, eget tincidunt nidictum porta.');
    })

    $('.mem2').click(function () {
        $('.mem-name').html("Alina");
        $('.mem-ab-text-area').fadeIn(300)
        $('.mem-fb').attr('href', 'https:/www.facebook/profile.php/alina02.com');
        $('.mem-tw').attr('href', 'https:/www.twitter/profile.php/alina02.com');
        $('.mem-ab').html('Vivamussuscipit tortor egetfelis porttitor volutpat. aliquet quam id dui posuere blandit. Nulla porttitor accumsan tincidunt. Cras ultricies ligula sed magna dictumporta. Curabitur non nulla sit amet nisl tempusconvallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec');


    })

    $('.mem3').click(function () {
        $('.mem-name').html("Mick");
        $('.mem-ab-text-area').fadeIn(300)
        $('.mem-fb').attr('href', 'https:/www.facebook/profile.php/mick22.com');
        $('.mem-tw').attr('href', 'https:/www.twitter/profile.php/mick22.com');
        $('.mem-ab').html('Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores placeat velit alias vero quis, ipsum voluptatum molestias eligendi ipsam ex.Dolores placeat velit Dolores placeat velit alias vero quis,  sit amet consectetur adipisicing elit. Dolores placeat velit alias');


    })

    $('.mem4').click(function () {
        $('.mem-name').html("Eve");
        $('.mem-ab-text-area').fadeIn(300)
        $('.mem-fb').attr('href', 'https:/www.facebook/profile.php/eve09.com');
        $('.mem-tw').attr('href', 'https:/www.twitter/profile.php/eve09.com');
        $('.mem-ab').html('Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamussuscipit tortor egetfelis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla porttitor accumsan tincidunt. Cras ultricies ligula sed magna dictumporta. Curabitur non nulla sit amet nisl tempusconvallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.Mauris blandit aliquet elit, eget tincidunt nidictum porta.');
    })

    $('.closer-text').click(function () {
        $('.mem-ab-text-area').fadeOut(300)
    })

    window.onload = function () {
        win.loopFun($('.skill1')[0], 90, '#FFF', '#ffe600', '#ffe600', '25px', 5, 60, 1500, 'easeInOut');
        win.loopFun($('.skill2')[0], 96, '#FFF', '#ffe600', '#ffe600', '25px', 5, 60, 1500, 'easeInOut');
        win.loopFun($('.skill3')[0], 85, '#FFF', '#ffe600', '#ffe600', '25px', 5, 60, 1500, 'easeInOut');
        win.loopFun($('.skill4')[0], 94, '#FFF', '#ffe600', '#ffe600', '25px', 5, 60, 1500, 'easeInOut');
    }

    $('#brandsCrousel').owlCarousel({
        items: 6,
        loop: true,
        nav: true,
        navText: ['<i class="fa-solid fa-angles-left"></i>', '<i class="fa-solid fa-angles-right"></i>'],
        dots: false,
        autoplay: true,
        autoplayTimeout: 2000,
    });

    $('#reviewCrousel').owlCarousel({
        items: 1,
        loop: true,
        nav: false,
        navText: ['<i class="fa-solid fa-angles-left"></i>', '<i class="fa-solid fa-angles-right"></i>'],
        dots: true,
        autoplay: true,
        autoplayTimeout: 3000,
    });

    $('#memCrousel').owlCarousel({
        items: 4,
        loop: false,
        nav: false,
        navText: ['<i class="fa-solid fa-angles-left"></i>', '<i class="fa-solid fa-angles-right"></i>'],
        dots: false,
        autoplay: false,
        autoplayTimeout: 3000,
        responsive: {


            0: {
                items: 1,
                dots: true,
                autoplay: true,
                loop: true,
            },

            450: {
                items: 1,
                dots: true,
                autoplay: true,
                loop: true,
            },

            575: {
                items: 1,
                dots: true,
                autoplay: true,
                loop: true,
            },

            767: {
                items: 1,
                dots: true,
                autoplay: true,
                loop: true,
            },

            991: {
                items: 4,
                dots: false,
                autoplay: false,
                loop: false,
            },

        }
    });

    $(window).click(function () {
        $('.mobile-menu-area').removeClass('menu-remove');
        $('.mobile-menu-area').addClass('menu-remove');
     });
  
     $(window).scroll(function () {
        $('.mobile-menu-area').removeClass('menu-remove');
        $('.mobile-menu-area').addClass('menu-remove');
     });
  
     $('.menu-bar').click(function () {
        $('.mobile-menu-area').toggleClass('menu-remove');
        return false;
     });


});
